GAME_ID = 'game_id'
HAND_ID = 'hand_id'
HAND_IDS = 'hand_ids'
FACE_CARD_SET = set(('K', 'Q', 'J', 'T'))
HAND_INDEX = 'hand_index'